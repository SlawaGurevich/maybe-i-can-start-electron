import withSecondaryScreen from './SecondaryView';

export default withSecondaryScreen;