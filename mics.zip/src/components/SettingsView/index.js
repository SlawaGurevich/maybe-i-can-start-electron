import SettingsView from './SettingsView';

export default SettingsView;