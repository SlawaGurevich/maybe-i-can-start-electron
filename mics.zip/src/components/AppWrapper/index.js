import AppWrapper from './AppWrapper';

export default AppWrapper;