export const HOME = '/';
export const OPTIONS = "/options";