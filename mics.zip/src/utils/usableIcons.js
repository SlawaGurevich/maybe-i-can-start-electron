import {
		faPalette,
		faPaintBrush,
		faLaptopCode,
		faTerminal
	} from '@fortawesome/free-solid-svg-icons';

const usableIcons = [
	faPalette,
	faPaintBrush,
	faLaptopCode,
	faTerminal,
]

export default usableIcons;