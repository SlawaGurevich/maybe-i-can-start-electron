module.exports = [require.resolve('./.webpack.config.js')]
